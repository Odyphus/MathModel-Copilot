# MathModel Copilot v0.3.0-preview.1 · 公测预览候选版

![MathModel 工作流](./assets/banner.svg)
![Version](https://img.shields.io/badge/version-v0.3.0-preview.1-8B5CF6)

MathModel Copilot 是面向数学建模比赛的 AI 建模助手，以 AI 技能包（Skill）的形式使用。它帮助队员与 AI 推进审题、方案比较、建模、计算、检查、论文准备和任务交接，并把进度与来源保存在同一份项目记录中。保留 mathmodel-skill 的十阶段建模流程，提供命令行工具、建模工作台与可选 Git 交接。论文由人主导，AI 辅助整理依据、推敲模型、检查遗漏和按需起草局部内容。

**建模工作台**是查看本机进展、成果、待处理事项并继续工作的页面，包含项目总览、各问进展、成果与依据、论文准备四个入口。功能名称和状态含义见 [产品术语与文案规范](docs/PRODUCT_LANGUAGE.md)。

Preview 2 改进了工作台续接：显示自上次已读后的变化、按实际记录列出题意与假设的待判断事项，并在刷新时保留详情和阅读位置。页面可见时每 15 秒读取本机状态，不调用 AI；失败或来源失效仍明确提示。点击“已看过”只更新本浏览器的阅读标记，不改变项目事实。见 [工作台内容规则](docs/DASHBOARD_CONTENT.md)。

**这是准备公测的预览候选版，尚未公开发布。** 上游 MIT 归因完整保留；迁入代码及新增派生材料的公开授权、实际维护者和仓库信息仍待确认，不能把整包宣称为 MIT 或正式开源版。见 [来源许可边界](LICENSE_SCOPE.md) 和 [上游说明](UPSTREAM.md)。没有替换任何原有安装。

## 快速开始

**0.3 Preview 新增**：随时进入教学、获准后保存关键过程并在收尾生成本地复盘、下次重查当前事实后续接、读取本人选定且适用的经验，以及可审阅的 GitHub 使用反馈发送器。建模内核、四个工作台入口和原安装保持独立；新能力详见 [0.3 使用说明](docs/EXPERIENCE_V03.md)。反馈发送需要真实接收仓库、本人授权及 GitHub 登录；本候选的实际送达验收状态见交付报告，不能把离线测试当真实 Issue。

先看 [简短使用说明](内测使用说明.md)。要求 Python 3.10+，以及能读写本地文件和运行程序的 AI 工具。基础体验无需安装分发包：打开解压目录，让 AI 读取 `SKILL.md` 后，在源码目录之外创建练习项目即可。

把题面和附件交给 AI 后，默认先带你梳理全题，再针对有真实替代思路的小问比较候选。通俗解释会落实到专业模型名称、数学结构、求解方法、验证和取舍；已经授权自主推进时，不逐阶段重复确认。论文由队员主导，AI 提供材料、批注和按需局部候选。

```console
python scripts/copilot.py --workspace ../demo-project demo
python scripts/copilot.py --workspace ../demo-project dashboard --port 8765
```

`demo-project` 必须为空或不存在；不要先在同一目录 `init` 再 `demo`。第二次使用只读取原项目并重开建模工作台，不重新生成 demo。Windows 常用 `python`，macOS/Linux 可用 `python3`。服务保持运行时，在浏览器访问终端给出的本机地址；它不需要 Node 或前端构建。

用户体验优先使用 `runtime` ZIP：只有一个 Skill 入口，把包交给 AI 安装即可。包含开发测试和插件入口的 `source` ZIP 供维护者使用，不要把整份开发目录当多个 Skill 批量安装。

需要安装独立 Python 命令时，使用 `source` 源码包，Windows PowerShell：

```console
python -m venv .venv
.venv\Scripts\python.exe -m pip install --no-cache-dir .
.venv\Scripts\mathmodel-copilot.exe --version
.venv\Scripts\mathmodel-copilot.exe --workspace ../demo-project demo
.venv\Scripts\mathmodel-copilot.exe --workspace ../demo-project status
.venv\Scripts\mathmodel-copilot.exe --workspace ../demo-project dashboard --port 8765
```

Linux 将命令前缀替换为 `.venv/bin/python` 和 `.venv/bin/mathmodel-copilot`。下文简写的 `mathmodel-copilot` 也指该环境中的可执行文件，无须修改系统 PATH。

内置示例会在新目录真实运行合成交通流模型及独立检查程序，首次运行不会复制旧结果。它是 MCM 历史背景下的合成软件演示，没有现场校准，也不会变成正式比赛的待提交状态。页面默认只读；需要记录建模意见时可以显式启用交互：

```console
python scripts/copilot.py --workspace ../demo-project dashboard --interactive
```

可选再加 `--assistant-codex --assistant-timeout 180`，尝试通过已配置的本地 Codex CLI 发起一次新的只读分析。它不接管当前桌面聊天；登录、额度与权限在实际提交时检查，成功回复才算执行成功。该实验入口与已验证的本地意见记录分开验收。详见 [交互说明](docs/LOCAL_INTERACTION.md)。

自己的项目可用 `mathmodel-copilot --workspace ../my-project init --competition cumcm` 创建；已有项目只续接，不覆盖。可选 Git 查看用 `mathmodel-copilot --workspace ../my-project git status`；没有 Git 或账号时仍可使用默认本地模式。

核心安装无第三方 Python 依赖。YAML、分析/绘图、文档检查、历史 XLS 和维护任务分别提供 optional extras。完整平台步骤、模块入口、Skill 安装及显式旧名兼容见 [安装文档](docs/INSTALL.md)。

## 工作方式

### 不用记住全部功能

首次开始完整练习时，AI 会先简短介绍工作方式，再直接梳理题目。项目建立后，环境允许就主动启动只读建模工作台并尝试展示；页面来自技能包，无需重新制作。不能自动打开时会说明原因并继续对话；你也可以直接说“不用页面”。只问一个局部问题或只要方案时，不另行启动工作台。

后续功能提示结合当前任务出现，不要求你读完文档或逐阶段回复“继续”。下面这些话都可以直接对 AI 说：

| 你现在想做什么 | 可以直接说 |
|---|---|
| 看清题目要求 | “先把每一问要解决什么、交什么列清楚。” |
| 比较建模方法 | “给我可比较的候选模型，说明数学结构、算法和取舍。” |
| 判断一个结果能不能用 | “这个数字有哪些依据，做过哪些检查？” |
| 调整模型或参数 | “我改了这个条件，哪些结果和论文内容要重新检查？” |
| 回来继续或交给队友 | “概括当前进展和下一步。”／“整理一份任务交接说明。” |
| 准备论文 | “先整理这一问的写作材料、图表建议和还缺的依据。” |
| 了解更多能力 | “你还能帮我做什么？”／“用独立示例带我体验主要功能。” |
| 随时学习一项功能 | “进入教学模式。”／“只教我怎样检查结果的依据。” |
| 收尾后下次继续 | “本项目可以记录关键过程，结束后帮我整理复盘，下次接着做。” |
| 保存使用偏好 | “以后保留专业术语并解释清楚，不要自动打开页面。” |
| 改进产品 | “把刚才的问题和相关过程整理成使用反馈，先给我看内容。” |

这些是对话用法，具体工作仍以实际记录和授权范围为准。默认页面只读；本地建模意见、额外 AI 分析与 Git 交接按需启用。使用反馈通过独立发送器处理，草稿、授权、尝试发送和实际送达分别记录。工作台启动、自动收尾和续接由执行 Skill 的 AI 完成，不是 `init` 自动打开浏览器或后台监听聊天；强制退出后需下次调用恢复。不能据此保证所有宿主已经通过首次体验验收。维护者可查看 [功能引导规则](references/feature_guidance.md)。

### 项目中的工作

| 工作 | 行为 |
|---|---|
| 题目要求 | 逐问整理题意与交付要求，形成题目要求清单；缺问或缺输出时明确提示 |
| 题意取舍 | 记录待明确的题意与建模假设；解释变化后提示受影响的模型和结果 |
| 模型方案 | 保留模型方案、参数设置、数据说明和候选取舍的依据 |
| 计算记录 | 实际运行程序，保留当次输入、环境、输出和结束情况，便于追溯与复现 |
| 结果检查 | 预先登记检查方案，实际执行独立检查程序；失败、超时、缺输出不算通过 |
| 结论依据 | 关联计算、检查、结果、论文结论和章节；依据变化后标明需要重新检查 |
| 任务交接 | 生成任务交接说明、汇总变化并检查版本冲突；接收、采用、核验分别记录 |
| 建模工作台 | 查看本机进展、成果和待处理事项；可选保存建模意见、请求分析和查看回复 |
| 队内交接（可选 Git） | 传递项目记录、提案与草稿；合并仍需检查才能采用，不自动推送或创建拉取请求 |
| 提交材料 | 检查具体文件并生成限定范围的材料包；材料检查通过、具备待提交条件、实际提交分别记录 |

`state/decision_log.json` 是唯一权威，根 schema 4.0、copilot 子树 0.1 与 v0.1.3 保持兼容；可选意见字段也通过原有 Store 事务保存。`.copilot/` 保存证据附件及本机执行缓存，不是第二套事实库。意见、AI 回复、实际采用和数学核验各有含义。工作阶段只作导航，方案评审分数只作建议；缺少运行、独立核验或需求覆盖时，旧 `submission_ready=true` 不会使项目可提交。

详细命令与 payload 见 [统一执行协议](references/copilot_runtime.md)；比赛工作由 [SKILL.md](SKILL.md) 按需加载赛事和阶段资料。维护此产品时不启动比赛问答。

需要给队友同步进度时，可让 AI 生成项目进展简报，避免直接沿用旧聊天里的数字：

```console
python scripts/copilot.py --workspace ../my-project report --output outputs/项目进展简报.md
```

该命令从与页面相同的实时观察生成需求完成度、有效结果、来源和待处理事项；不采用外部报告自述，也不覆盖同名历史简报。重新生成时使用新文件名。它不会把已运行改成已核验，也不会改变项目状态。报告仅代表生成时刻。

## 范围与证据

CUMCM / MCM-ICM / 电工杯及 generic/custom 共享内核，但某赛事配置存在不等于完整案例已经验收。清洁包不含官方题面和 XLS 附件；[历史附件说明](docs/HISTORICAL_FIXTURES.md) 给独立取用步骤，内部完整案例证据另行交付。

DOCX 回读继续明确拒绝不受支持的符号、字段和未知可见构造。Word 与 TeX、实际编译与来源链、程序回归与独立 Agent/真人接力分别验收。状态、哈希和测试不能证明自然语言论证、全局最优、人工签字或正式投稿已经完成。

实际运行环境、失败/跳过项、最终候选哈希见随包验收报告；CI 配置不是远程运行证明。详见 [支持矩阵](docs/SUPPORT_MATRIX.md)、[DOCX 支持边界](docs/DOCX_INLINE_V013.md) 和 [变更记录](CHANGELOG.md)。

本轮修复范围和公开分发前的剩余条件见 [Preview 准备说明](docs/PREVIEW_READINESS.md)。软件回归、真实宿主调用、跨平台执行、人工论文终审分别验收。

## 维护与恢复

- [安装与首次使用](docs/INSTALL.md)、[升级/恢复/卸载](docs/UPGRADE_ROLLBACK.md)、[常见问题](docs/TROUBLESHOOTING.md)
- [贡献指南](CONTRIBUTING.md)、[安全与私有材料](SECURITY.md)、[构建与发行](docs/MAINTENANCE.md)
- [架构](docs/IMPLEMENTATION.md)、[迁入清单](docs/MIGRATION.md)、[宿主/赛事包](docs/ADAPTERS.md)、[论文交付](docs/DELIVERY.md)
- [第三方通知](THIRD_PARTY_NOTICES.md)、[上游原说明存档](docs/UPSTREAM_README.md)

发行主名为 `mathmodel-copilot`；旧 `mathmodel-skill` 仅能显式创建兼容薄入口，任何已有同名安装都拒绝覆盖。准备好候选、技术验收通过、来源许可确认、获得公开授权和实际发布是不同状态。

### 建模工作台

首页面向个人查看本机已登记的项目进展。四个主入口为项目总览、各问进展、成果与依据、论文准备；当前方案和题目目标归入各问，人工待确认事项只在确有记录时出现。空栏目自动收起。

普通界面使用中文名称，不显示哈希、内部编号或项目识别码。必要诊断通过导出记录保留，原始文件按明确的原文入口查看。不会自动同步队友状态；可选交互只记录意见和分析，不直接采用模型、复算或提交论文。查看[工作台内容与状态规则](docs/DASHBOARD_CONTENT.md)。
